
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="A browser extension to customize Facebook reactions. Made by the team behind J2TEAM Security.">
    <meta name="author" content="T-Rekt">
    <meta name="copyright" content="J2TEAM">
    <meta name="robots" content="index, follow">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="https://reactions.thao.pw/assets/icons/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">

    <!-- Facebook -->
    <meta property="og:title" content="Custom reactions for Facebook">
    <meta property="og:description" content="A browser extension to customize Facebook reactions. Made by the team behind J2TEAM Security.">
    <meta property="og:url" content="https://j2team.dev">
    <meta property="og:type" content="website">
    <meta property="og:image" content="https://i.imgur.com/xX7hLwm.jpg">
    <meta property="og:image:width" content="600">
    <meta property="og:image:height" content="315">
    <meta property="og:image:alt" content="custom-facebook-reactions">
    <meta property="og:site_name" content="J2TEAM">
    <meta property="og:locale" content="en_US">
    <meta property="fb:admins" content="100009563844355">
    <meta property="fb:app_id" content="458084867627529">

    <title>Thành PC For Facebook</title>
    <link href="https://cdnjs.cloudflare.com" rel="preconnect" crossorigin>
    <link href="https://cdnjs.cloudflare.com" rel="dns-prefetch">
    <link rel="apple-touch-icon" sizes="57x57" href="https://reactions.thao.pw/assets/icons/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="https://reactions.thao.pw/assets/icons/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="https://reactions.thao.pw/assets/icons/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="https://reactions.thao.pw/assets/icons/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="https://reactions.thao.pw/assets/icons/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="https://reactions.thao.pw/assets/icons/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="https://reactions.thao.pw/assets/icons/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="https://reactions.thao.pw/assets/icons/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="https://reactions.thao.pw/assets/icons/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="https://reactions.thao.pw/assets/icons/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="https://reactions.thao.pw/assets/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="https://reactions.thao.pw/assets/icons/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="https://reactions.thao.pw/assets/icons/favicon-16x16.png">
    <link rel="manifest" href="https://reactions.thao.pw/assets/icons/manifest.json">
    
    <!-- CSS only -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.min.css">
    <style>body {background-image: linear-gradient(70deg, #84fab0 0%, #8fd3f4 100%);}</style>
    <link rel="stylesheet" href="https://reactions.thao.pw/assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/notie/4.3.1/notie.min.css">


  </head>
  <body>
    <div id="main">
      <div class="container">
        <div class="row">
          <div class="col text-center mt-4">
            <h1>Custom reactions for Facebook</h1>
          </div>
        </div>
        <div class="row">
          <div class="col text-center mt-2 mb-4">
            <a href="https://chrome.google.com/webstore/detail/custom-reactions-for-face/jmjojkilgdbcgdemnopinafimpidclcb/" target="_blank" rel="noopener nofollow">
              <img src="https://developer.chrome.com/webstore/images/ChromeWebStore_BadgeWBorder_v2_206x58.png" class="install-button" loading="lazy" width="206" height="58" alt="custom-facebook-reactions-extension">
            </a>
          </div>
        </div>
        <div class="row">
          <div class="col">
            <div class="alert alert-danger" v-if="!extensionCommunication">
              <strong>Error:</strong> Can't communicate with extension. Please <a href="https://chrome.google.com/webstore/detail/custom-reactions-for-face/jmjojkilgdbcgdemnopinafimpidclcb/" class="text-primary" target="_blank" rel="noopener nofollow">install our Chrome extension</a> and <a href="#" class="text-primary" @click.prevent="reloadPage">refresh this page</a>!
            </div>
            <div class="alert alert-warning">
              <strong>Note:</strong> You need to upload square images, else they would be distorted.
            </div>
          </div>
        </div>
        <div class="row mb-4">
          <div class="col">
            <form action="#" method="post">
              <div class="form-row mb-3">
                <div class="form-group col-md-5 mb-0">
                  <label for="reaction-pack-name" class="sr-only">Reactions pack name</label>
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text font-weight-bold">Reactions pack name</span>
                    </div>
                    <input type="text" class="form-control text-center" id="reaction-pack-name" v-model="name" aria-describedby="reactions-pack-name" required>
                  </div>
                </div>
              </div>
              <div class="form-row mb-3">
                <div class="form-group col-md-3 mb-0">
                  <label for="reaction-size" class="sr-only">Reactions size</label>
                  <div class="input-group input-group-sm">
                    <div class="input-group-prepend">
                      <span class="input-group-text font-weight-bold">Reactions size</span>
                    </div>
                    <input type="number" class="form-control text-center" id="reaction-size" v-model="size" minlength="2" maxlength="3" min="40" max="100" aria-describedby="reactions-size" required @input="checkSize">
                    <div class="input-group-append">
                      <span class="input-group-text" id="reactions-size">px</span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="form-row">
                <div class="form-group col-md-3 mb-0">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="public" v-model="public">
                    <label class="form-check-label" for="public">
                      Show on public reactions store
                    </label>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
        <div class="row mb-3">
          <div class="col-md-3 pb-3 mx-auto" v-for="k in Object.keys(files)">
            <div class="card shadow reaction-card">
              <div class="card-body">
                <div class="container-fluid">
                  <div class="row mb-3">
                    <div class="col d-flex flex-row justify-content-center align-items-center">
                      <img :src="files[k].selectedImage ? files[k].selectedImage : files[k].defaultImage" :data-reaction-type="k" :alt="k" :width="size" :height="size" class="rounded-circle img img-responsive" loading="lazy">
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col">
                      <input type="text" class="form-control text-center name-input" v-model="files[k].text">
                    </div>
                  </div>
                  <div class="row">
                    <div class="col text-center">
                      <button class="btn btn-block btn-sm btn-primary" @click="document.querySelector(`#selectFile-${k}`).click()">Choose file</button>

                      <form enctype="multipart/form-data" hidden>
                        <input type="file" :data-reaction-type="k" @change="selectFile" accept=".png,.jpg,.gif" class="form-control" :id="`selectFile-${k}`">
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row mb-3" v-if="shareLink">
          <div class="col-md-6 offset-md-3 text-center">
            <div class="row">
              <div class="col-md-3 float-left">
                Share link:
              </div>
              <div class="col-md-9 float-right">
                <input type="url" readonly v-model="shareLink" class="form-control">
              </div>
            </div>
          </div>
        </div>
        <div class="row mb-3">
          <div class="col text-center">
            <button class="btn btn-lg btn-primary" :class="{disabled: !extensionCommunication}" :disabled="!extensionCommunication" @click="sendToExtension">Thay Đổi</button>
            <button class="btn btn-lg btn-warning" @click="createShareLink">Create share link</button>
            <a href="https://reactions.thao.pw/?id=NUTX4NWMW9" class="btn btn-lg btn-secondary">Death Click Reactions</a>
            <div v-if="successMsg" class="text-success mt-2">{{ successMsg }}</div>
          </div>
        </div>
      </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/vue/2.6.12/vue.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.20.0/axios.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/notie/4.3.1/notie.min.js"></script>
    <script src="https://reactions.thao.pw/assets/js/ImageTools.js"></script>
    <script src="https://reactions.thao.pw/assets/js/main.js"></script>
  </body>
</html>