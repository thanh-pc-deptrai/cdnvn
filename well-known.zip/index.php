<!DOCTYPE html>
<html>
<head>
<title>Thành PC</title>
<meta name="description" content="Thành PC Là Ai"/>
    <meta name="keywords" content="Thành PC Là Ai" />
<style>
    body {
        width: 35em;
        margin: 0 auto;
        font-family: Tahoma, Verdana, Arial, sans-serif;
    }
</style>
</head>
<body>
<h1>Chào Mừng Bạn Đã Đến Với Cdn Việt Nam!</h1>
<p>Nếu bạn thấy trang này, máy chủ web CdnVn.Tk đã được cài đặt và hoạt động thành công. Cần phải cấu hình thêm.</p>
<p>Để có tài liệu trực tuyến và hỗ trợ, vui lòng tham khảo
<a href="https://Live.CdnVn.tk/">Live.CdnVn.Tk</a>.<br/>
Hỗ trợ thương mại có sẵn tại
<a href="https://Live.CdnVn.tk/">Live.CdnVn.Tk</a>.</p>

<p><em>Thank you for using CdnVn.</em></p>
</body>
</html>
